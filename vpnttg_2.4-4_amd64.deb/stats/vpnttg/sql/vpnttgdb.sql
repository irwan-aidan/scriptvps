SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

CREATE PROCEDURAL LANGUAGE plpgsql;

ALTER PROCEDURAL LANGUAGE plpgsql OWNER TO vpnttg;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;





CREATE SEQUENCE mailer_hostid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER TABLE public.mailer_hostid_seq OWNER TO vpnttg;

CREATE TABLE mailer (
    hostid integer DEFAULT nextval('mailer_hostid_seq'::regclass) NOT NULL,
    userid integer NOT NULL,
    smtphost character varying NOT NULL,
    smtpport integer NOT NULL,
    smtpsecure character varying(4) NOT NULL,
    smtpauth boolean DEFAULT false NOT NULL,
    smtpuser character varying NOT NULL,
    smtppass character varying NOT NULL
);

ALTER TABLE public.mailer OWNER TO vpnttg;





CREATE SEQUENCE userlogs_logid_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

ALTER TABLE public.userlogs_logid_seq OWNER TO vpnttg;

CREATE TABLE userlogs (
    logid integer DEFAULT nextval('userlogs_logid_seq'::regclass) NOT NULL,
    userid integer NOT NULL,
    ipaddr inet NOT NULL,
    session character varying,
    firsttime timestamp without time zone,
    lasttime timestamp without time zone,
    status boolean DEFAULT true
);

ALTER TABLE public.userlogs OWNER TO vpnttg;





CREATE SEQUENCE users_userid_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

ALTER TABLE public.users_userid_seq OWNER TO vpnttg;

CREATE TABLE users (
    userid integer DEFAULT nextval('users_userid_seq'::regclass) NOT NULL,
    username character varying NOT NULL,
    password character varying NOT NULL,
    admin boolean DEFAULT false,
    timeout integer DEFAULT 3600 NOT NULL,
    name character varying,
    email character varying
);

ALTER TABLE public.users OWNER TO vpnttg;





CREATE SEQUENCE devicelogs_logid_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

ALTER TABLE public.devicelogs_logid_seq OWNER TO vpnttg;

CREATE TABLE devicelogs (
    logid integer DEFAULT nextval('devicelogs_logid_seq'::regclass) NOT NULL,
    deviceid integer NOT NULL,
    starttime timestamp without time zone,
    stoptime timestamp without time zone
);

ALTER TABLE public.devicelogs OWNER TO vpnttg;





CREATE SEQUENCE devices_deviceid_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

ALTER TABLE public.devices_deviceid_seq OWNER TO vpnttg;

CREATE TABLE devices (
    deviceid integer DEFAULT nextval('devices_deviceid_seq'::regclass) NOT NULL,
    deviceip inet NOT NULL,
    devicename character varying(64),
    community character varying(32),
    firsttime timestamp without time zone,
    lasttime timestamp without time zone,
    status boolean DEFAULT false,
    email character varying,
    alert boolean DEFAULT false
);

ALTER TABLE public.devices OWNER TO vpnttg;





CREATE SEQUENCE l2likelogs_logid_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

ALTER TABLE public.l2likelogs_logid_seq OWNER TO vpnttg;

CREATE TABLE l2likelogs (
    logid integer DEFAULT nextval('l2likelogs_logid_seq'::regclass) NOT NULL,
    peerid integer NOT NULL,
    starttime timestamp without time zone,
    stoptime timestamp without time zone,
    iketunnel integer
);

ALTER TABLE public.l2likelogs OWNER TO vpnttg;





CREATE SEQUENCE l2likepeers_peerid_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

ALTER TABLE public.l2likepeers_peerid_seq OWNER TO vpnttg;

CREATE TABLE l2likepeers (
    peerid integer DEFAULT nextval('l2likepeers_peerid_seq'::regclass) NOT NULL,
    deviceid integer NOT NULL,
    peername character varying,
    peerip inet NOT NULL,
    firsttime timestamp without time zone,
    lasttime timestamp without time zone,
    iketunnel integer,
    ipsectunnels integer,
    dinoctets bigint,
    doutoctets bigint,
    status boolean,
    email character varying,
    alert boolean DEFAULT false
);

ALTER TABLE public.l2likepeers OWNER TO vpnttg;





CREATE SEQUENCE l2lipseclogs_logid_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

ALTER TABLE public.l2lipseclogs_logid_seq OWNER TO vpnttg;

CREATE TABLE l2lipseclogs (
    logid integer DEFAULT nextval('l2lipseclogs_logid_seq'::regclass) NOT NULL,
    peerid integer NOT NULL,
    starttime timestamp without time zone,
    stoptime timestamp without time zone,
    iketunnel integer,
    ipsectunnel integer
);

ALTER TABLE public.l2lipseclogs OWNER TO vpnttg;





CREATE SEQUENCE l2lipsecpeers_peerid_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

ALTER TABLE public.l2lipsecpeers_peerid_seq OWNER TO vpnttg;

CREATE TABLE l2lipsecpeers (
    peerid integer DEFAULT nextval('l2lipsecpeers_peerid_seq'::regclass) NOT NULL,
    deviceid integer NOT NULL,
    peername character varying,
    localtype integer,
    localaddr1 inet NOT NULL,
    localaddr2 inet NOT NULL,
    peerip inet NOT NULL,
    remotetype integer,
    remoteaddr1 inet NOT NULL,
    remoteaddr2 inet NOT NULL,
    firsttime timestamp without time zone,
    lasttime timestamp without time zone,
    iketunnel integer,
    ipsectunnel integer,
    dinoctets bigint,
    doutoctets bigint,
    status boolean,
    email character varying,
    alert boolean DEFAULT false
);

ALTER TABLE public.l2lipsecpeers OWNER TO vpnttg;





CREATE SEQUENCE ipsecpeers_peerid_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

ALTER TABLE public.ipsecpeers_peerid_seq OWNER TO vpnttg;

CREATE TABLE ipsecpeers (
    peerid integer DEFAULT nextval('ipsecpeers_peerid_seq'::regclass) NOT NULL,
    deviceid integer NOT NULL,
    username character varying,
    groupname character varying,
    localtype integer,
    localaddr1 inet NOT NULL,
    localaddr2 inet NOT NULL,
    peerip inet NOT NULL,
    remotetype integer,
    remoteaddr1 inet NOT NULL,
    remoteaddr2 inet NOT NULL,
    firsttime timestamp without time zone,
    lasttime timestamp without time zone,
    iketunnel integer,
    ipsectunnel integer,
    inoctets bigint,
    outoctets bigint,
    dinoctets bigint,
    doutoctets bigint
);

ALTER TABLE public.ipsecpeers OWNER TO vpnttg;





CREATE SEQUENCE raipseclogs_logid_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

ALTER TABLE public.raipseclogs_logid_seq OWNER TO vpnttg;

CREATE TABLE raipseclogs (
    logid integer DEFAULT nextval('raipseclogs_logid_seq'::regclass) NOT NULL,
    peerid integer NOT NULL,
    groupname character varying,
    ispaddr inet NOT NULL,
    localaddr inet NOT NULL,
    starttime timestamp without time zone,
    stoptime timestamp without time zone,
    iketunnel integer,
    ipsectunnel integer
);

ALTER TABLE public.raipseclogs OWNER TO vpnttg;





CREATE SEQUENCE raipsecpeers_peerid_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

ALTER TABLE public.raipsecpeers_peerid_seq OWNER TO vpnttg;

CREATE TABLE raipsecpeers (
    peerid integer DEFAULT nextval('raipsecpeers_peerid_seq'::regclass) NOT NULL,
    deviceid integer NOT NULL,
    username character varying,
    groupname character varying,
    ispaddr inet NOT NULL,
    localaddr inet NOT NULL,
    firsttime timestamp without time zone,
    lasttime timestamp without time zone,
    iketunnel integer,
    ipsectunnel integer,
    dinoctets bigint,
    doutoctets bigint,
    status boolean,
    email character varying,
    alert boolean DEFAULT false
);

ALTER TABLE public.raipsecpeers OWNER TO vpnttg;





CREATE SEQUENCE sslpeers_peerid_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

ALTER TABLE public.sslpeers_peerid_seq OWNER TO vpnttg;

CREATE TABLE sslpeers (
    peerid integer DEFAULT nextval('sslpeers_peerid_seq'::regclass) NOT NULL,
    deviceid integer NOT NULL,
    username character varying,
    groupname character varying,
    ispaddr inet NOT NULL,
    localaddr inet NOT NULL,
    firsttime timestamp without time zone,
    lasttime timestamp without time zone,
    svc boolean,
    tunnel integer,
    inoctets bigint,
    outoctets bigint,
    dinoctets bigint,
    doutoctets bigint
);

ALTER TABLE public.sslpeers OWNER TO vpnttg;





CREATE SEQUENCE svclogs_logid_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

ALTER TABLE public.svclogs_logid_seq OWNER TO vpnttg;

CREATE TABLE svclogs (
    logid integer DEFAULT nextval('svclogs_logid_seq'::regclass) NOT NULL,
    peerid integer NOT NULL,
    groupname character varying,
    ispaddr inet NOT NULL,
    localaddr inet NOT NULL,
    starttime timestamp without time zone,
    stoptime timestamp without time zone,
    tunnel integer
);

ALTER TABLE public.svclogs OWNER TO vpnttg;





CREATE SEQUENCE svcpeers_peerid_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

ALTER TABLE public.svcpeers_peerid_seq OWNER TO vpnttg;

CREATE TABLE svcpeers (
    peerid integer DEFAULT nextval('svcpeers_peerid_seq'::regclass) NOT NULL,
    deviceid integer NOT NULL,
    username character varying,
    groupname character varying,
    ispaddr inet NOT NULL,
    localaddr inet NOT NULL,
    firsttime timestamp without time zone,
    lasttime timestamp without time zone,
    tunnel integer,
    dinoctets bigint,
    doutoctets bigint,
    status boolean,
    email character varying,
    alert boolean DEFAULT false
);

ALTER TABLE public.svcpeers OWNER TO vpnttg;





CREATE SEQUENCE webvpnlogs_logid_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

ALTER TABLE public.webvpnlogs_logid_seq OWNER TO vpnttg;

CREATE TABLE webvpnlogs (
    logid integer DEFAULT nextval('webvpnlogs_logid_seq'::regclass) NOT NULL,
    peerid integer NOT NULL,
    groupname character varying,
    ispaddr inet NOT NULL,
    starttime timestamp without time zone,
    stoptime timestamp without time zone,
    tunnel integer
);

ALTER TABLE public.webvpnlogs OWNER TO vpnttg;





CREATE SEQUENCE webvpnpeers_peerid_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

ALTER TABLE public.webvpnpeers_peerid_seq OWNER TO vpnttg;

CREATE TABLE webvpnpeers (
    peerid integer DEFAULT nextval('webvpnpeers_peerid_seq'::regclass) NOT NULL,
    deviceid integer NOT NULL,
    username character varying,
    groupname character varying,
    ispaddr inet NOT NULL,
    firsttime timestamp without time zone,
    lasttime timestamp without time zone,
    tunnel integer,
    dinoctets bigint,
    doutoctets bigint,
    status boolean,
    email character varying,
    alert boolean DEFAULT false
);

ALTER TABLE public.webvpnpeers OWNER TO vpnttg;





COPY mailer (userid, smtphost, smtpport, smtpsecure, smtpauth, smtpuser, smtppass) FROM stdin;
1	localhost	25	None	f	 	 
\.

COPY users (username, password, admin, timeout, name, email) FROM stdin;
admin	$1$6LNaoUPf$mLtTWaqCQ1x7tCPhM9XDI1	t	3600	VPNTTG Admin	noreply@localhost.localdomain
guest	$1$6LNaoUPf$mLtTWaqCQ1x7tCPhM9XDI1	f	3600	VPNTTG Guest	noreply@localhost.localdomain
\.





ALTER TABLE ONLY mailer
    ADD CONSTRAINT mailer_pkey PRIMARY KEY (hostid);

ALTER TABLE ONLY userlogs
    ADD CONSTRAINT userlogs_session_key UNIQUE (session);

ALTER TABLE ONLY userlogs
    ADD CONSTRAINT userlogs_pkey PRIMARY KEY (logid);

ALTER TABLE ONLY users
    ADD CONSTRAINT users_username_key UNIQUE (username);

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (userid);

ALTER TABLE ONLY devicelogs
    ADD CONSTRAINT devicelogs_pkey PRIMARY KEY (logid);

ALTER TABLE ONLY devices
    ADD CONSTRAINT devices_deviceip_key UNIQUE (deviceip);

ALTER TABLE ONLY devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (deviceid);

ALTER TABLE ONLY l2likelogs
    ADD CONSTRAINT l2likelogs_pkey PRIMARY KEY (logid);

ALTER TABLE ONLY l2likepeers
    ADD CONSTRAINT l2likepeers_pkey PRIMARY KEY (peerid);

ALTER TABLE ONLY l2lipseclogs
    ADD CONSTRAINT l2lipseclogs_pkey PRIMARY KEY (logid);

ALTER TABLE ONLY l2lipsecpeers
    ADD CONSTRAINT l2lipsecpeers_pkey PRIMARY KEY (peerid);

ALTER TABLE ONLY ipsecpeers
    ADD CONSTRAINT ipsecpeers_pkey PRIMARY KEY (peerid);

ALTER TABLE ONLY raipseclogs
    ADD CONSTRAINT raipseclogs_pkey PRIMARY KEY (logid);

ALTER TABLE ONLY raipsecpeers
    ADD CONSTRAINT raipsecpeers_pkey PRIMARY KEY (peerid);

ALTER TABLE ONLY sslpeers
    ADD CONSTRAINT sslpeers_pkey PRIMARY KEY (peerid);

ALTER TABLE ONLY svclogs
    ADD CONSTRAINT svclogs_pkey PRIMARY KEY (logid);

ALTER TABLE ONLY svcpeers
    ADD CONSTRAINT svcpeers_pkey PRIMARY KEY (peerid);

ALTER TABLE ONLY webvpnlogs
    ADD CONSTRAINT webvpnlogs_pkey PRIMARY KEY (logid);

ALTER TABLE ONLY webvpnpeers
    ADD CONSTRAINT webvpnpeers_pkey PRIMARY KEY (peerid);





REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;
