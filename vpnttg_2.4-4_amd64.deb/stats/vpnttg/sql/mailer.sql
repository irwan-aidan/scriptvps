UPDATE users SET name='VPNTTG Admin', email='noreply@localhost.localdomain' WHERE username='admin' AND name ISNULL; 
UPDATE users SET name='VPNTTG Guest', email='noreply@localhost.localdomain' WHERE username='guest' AND name ISNULL; 
UPDATE users SET name='' WHERE name ISNULL;

CREATE SEQUENCE mailer_hostid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER TABLE public.mailer_hostid_seq OWNER TO vpnttg;

CREATE TABLE mailer (
    hostid integer DEFAULT nextval('mailer_hostid_seq'::regclass) NOT NULL,
    userid integer NOT NULL,
    smtphost character varying NOT NULL,
    smtpport integer NOT NULL,
    smtpsecure character varying(4) NOT NULL,
    smtpauth boolean DEFAULT false NOT NULL,
    smtpuser character varying NOT NULL,
    smtppass character varying NOT NULL
);

ALTER TABLE public.mailer OWNER TO vpnttg;

ALTER TABLE ONLY mailer
    ADD CONSTRAINT mailer_pkey PRIMARY KEY (hostid);

COPY mailer (userid, smtphost, smtpport, smtpsecure, smtpauth, smtpuser, smtppass) FROM stdin;
1	localhost	25	None	f	 	
\.
